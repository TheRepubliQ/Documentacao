package br.edu.ifsp.aluno.api.republicas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRepublicasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRepublicasApplication.class, args);
	}

}
