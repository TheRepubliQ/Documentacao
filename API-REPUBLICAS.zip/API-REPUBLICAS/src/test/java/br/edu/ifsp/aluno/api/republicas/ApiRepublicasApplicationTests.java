package br.edu.ifsp.aluno.api.republicas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRepublicasApplicationTests {

	@Test
	void contextLoads() {
	}

}
